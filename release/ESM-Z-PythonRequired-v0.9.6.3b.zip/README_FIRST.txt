ESM-Z v0.9.6.3b
Requires Windows and Python 3.11+.
Run Run ESM-Z.bat, then open http://127.0.0.1:8080.
For manual updates, stop ESM-Z and preserve enshrouded_manager/data.
See docs/BETA_CHANNEL.md for beta switching and installation instructions.
