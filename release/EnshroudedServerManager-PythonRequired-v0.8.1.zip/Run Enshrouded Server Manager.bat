@echo off
cd /d "%~dp0"
echo Starting Enshrouded Server Manager...
echo.
py -3 "%~dp0enshrouded_manager\manager.py"
if errorlevel 1 (
  echo.
  echo Could not start with the Python launcher. Trying python.exe from PATH...
  python "%~dp0enshrouded_manager\manager.py"
)
pause
