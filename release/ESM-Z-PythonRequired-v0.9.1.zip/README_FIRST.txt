ESM-Z - Enshrouded Server Manager by Zat
Python Required Install

This package is for servers that already have Python 3.11+ installed.

1. Extract this ZIP anywhere on the server, for example:
   C:\ESM-Z

2. Double-click:
   Run ESM-Z.bat

3. Open this on the server:
   http://127.0.0.1:8080

By default the manager only listens on localhost, so port 8080 is not exposed
to the network. To access it from another PC, open the Manager tab locally,
change Listen address to "All network interfaces", set the port you want,
save, and restart the manager.

On first load, use Setup & Instances to point to an existing Enshrouded
dedicated server install or install a new server. The manager will download
SteamCMD and then install the dedicated server.

Regular user instructions are in:
enshrouded_manager\USER_README.md

The manager includes an Updates tab. Running game servers are persistent and
are not intentionally stopped when the manager is closed for an update.

Local access does not require a password by default. Remote access uses the
generated admin password in:
enshrouded_manager\data\manager.log
