@echo off
cd /d "%~dp0"
py -3 "%~dp0enshrouded_manager\manager.py"
if errorlevel 1 python "%~dp0enshrouded_manager\manager.py"
pause
